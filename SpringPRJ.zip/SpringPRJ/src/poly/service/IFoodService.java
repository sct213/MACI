package poly.service;

public interface IFoodService {
	
	int getFoodInfoFromWeb() throws Exception;
}
