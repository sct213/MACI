package poly.service;

public interface IDummyService {

}
