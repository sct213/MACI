package poly.service;

public interface IMovieService {
	
	int getMovieInfoFromWEB() throws Exception;
}
